/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments */
/* Host test of firmware/src/ota.c: a fake M-UPGRADE serves a real .fwsc over
 * the SysEx protocol (pack7, cmd 0x30 reads, 0xE0000000 -> "success") and a
 * simulated NOR plays the flash.
 *   cc -o ota_test tests/ota_test.c && ./ota_test FILE.fwsc
 * SMK-37 (-DBOARD_SMK37=1): `./ota_test M-VAVE.fwsc official` takes M-VAVE's own package (its 36 interleave blocks):
 * the app stages its own loader (SMK_LDR, made here) in place of the package's, under the stock record name.
 * ((2.0.2, #64) FM-1: `./ota_test FM-1.fwsc official`, M-VAVE's V15 or V16: their loader staged as it is, after the
 * head check.)
 */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#if BOARD_SMK37                          /* -DBOARD_SMK37=1: the SMK-37 Pro build of ota.c */
#if T_MODEL == 1                         /* -DT_MODEL=1 / 2: the MODEL=elite / mke build */
#define SMK_MODEL "SMK-37 Elite"
#elif T_MODEL == 2
#define SMK_MODEL "MKE-P37"
#else
#define SMK_MODEL "SMK-37 Pro"
#endif
#define FELUCCA_ID SMK_MODEL "_900"
#define T_AREA 0xBB000u
#define T_FL_LEN "0x9D000"               /* flash.bin: this board's [0, app area end) */
#define T_FL_OTHER 0x93000u              /* the other board's (the FM-1's) */
#define T_FL_OTHER_NAME "0x93000"
#define T_PARM_ID "ota-" SMK_MODEL "_016"
#define T_SMK 1
#define OTA_LDR_HOST 1                   /* ota.c: SMK_LDR from here, not build/gen's (made by make_own_ldr) */
static uint8_t SMK_LDR[0x1F00];
static uint32_t smk_ldr_len;
#define SMK_LDR_LEN smk_ldr_len
#else
#define FELUCCA_ID "FM-1_900"
#define T_AREA 0xE0000u
#define T_PARM_ID "ota-FM-1_015"
#define T_FL_LEN "0x93000"
#define T_FL_OTHER 0x9D000u              /* an SMK-37 Pro package's */
#define T_FL_OTHER_NAME "0x9D000"
#define T_FL_V16 0xA9000u                /* ((2.0.2, #64) M-VAVE's V16's: with the official loader only) */
#define T_SMK 0
#endif
#define T_AREA_HI (T_AREA + 0x5000u)
#define FELUCCA_OTA_DRYRUN 0

static uint8_t nor[0x100000];
static uint8_t *logical;
static size_t logical_len;
static uint8_t rx[1024];                 /* one pending host frame (7-bit bytes) */
static uint32_t rx_len, rx_full;
static uint32_t now_ms, requests, ident_replies, mute_after = 0xFFFFFFFFu, bad_erase, erases;
static int committed;
static uint8_t committed_parm[112];
static int32_t last_code;
static uint8_t *corrupt_at;              /* flip a served byte (loader body) */

static uint32_t pack7(const uint8_t *in, uint32_t n, uint8_t *out)
{
    uint32_t acc = 0, nb = 0, o = 0;
    while (n--) {
        acc |= (uint32_t)*in++ << nb;
        nb += 8;
        while (nb >= 7) { out[o++] = acc & 0x7F; acc >>= 7; nb -= 7; }
    }
    if (nb) out[o++] = acc & 0x7F;
    return o;
}

static uint32_t unpack7h(const uint8_t *in, uint32_t n, uint8_t *out)
{
    uint32_t acc = 0, nb = 0, o = 0;
    while (n--) {
        acc |= (uint32_t)*in++ << nb;
        nb += 7;
        if (nb >= 8) { out[o++] = (uint8_t)acc; acc >>= 8; nb -= 8; }
    }
    return o;
}

static void host_reply(const uint8_t *msg, uint32_t n)       /* queue msg as a device-bound frame */
{
    rx_len = pack7(msg, n, rx);
    rx_full = 1;
}

/* ---- hooks ---- */
static int ota_wire_send(const uint8_t *p, uint32_t n)
{
    uint8_t u[64], m[600];
    uint32_t d, addr, len, i, s = 0;
    if (p[0] != 0xF0 || p[n - 1] != 0xF7) { printf("bad wire framing\n"); exit(1); }
    d = unpack7h(p + 1, n - 2, u);
    if (u[2] == 0x11) { ident_replies++; return 0; }
    if (d != 15 || u[2] != 0x30) { printf("unexpected device msg cmd %02x len %u\n", u[2], d); exit(1); }
    addr = u[7] | u[8] << 8 | u[9] << 16 | (uint32_t)u[10] << 24;
    len = u[11] | u[12] << 8 | u[13] << 16;
    if (++requests > mute_after)
        return 0;                                         /* host gone */
    memcpy(m, "\x00\x59\x30", 3);
    m[3] = (uint8_t)(len + 8); m[4] = (uint8_t)((len + 8) >> 8); m[5] = 0;
    m[6] = 0;
    memcpy(m + 7, &addr, 4);
    m[11] = (uint8_t)len; m[12] = (uint8_t)(len >> 8); m[13] = 0;
    if (addr == 0xE0000000u) {
        memset(m + 14, 0, len);
        memcpy(m + 14, "success", 8);
    } else {
        if (addr + len > logical_len) { printf("read past the package %#x\n", addr); exit(1); }
        memcpy(m + 14, logical + addr, len);
        if (corrupt_at && corrupt_at >= logical + addr && corrupt_at < logical + addr + len)
            m[14 + (corrupt_at - (logical + addr))] ^= 0x01;
    }
    for (i = 6; i < 14 + len; i++) s += m[i];
    m[14 + len] = (uint8_t)~s;
    host_reply(m, 15 + len);
    return 0;
}
static int ota_frame_get(const uint8_t **p, uint32_t *n)
{
    if (!rx_full) return 0;
    *p = rx; *n = rx_len;
    return 1;
}
static void ota_frame_done(void) { rx_full = 0; }
static uint32_t ota_now_ms(void) { return now_ms; }
static void ota_idle(void) { now_ms += 1; }
static int ota_erase(uint32_t off)
{
    if (off < T_AREA || off >= T_AREA_HI || (off & 0xFFFu)) { bad_erase++; return -8; }
    erases++;
    memset(nor + off, 0xFF, 4096);
    return 0;
}
static int ota_prog(uint32_t off, const void *src, uint32_t n)
{
    const uint8_t *s = src;
    uint32_t i;
    if (off < T_AREA || off + n > T_AREA_HI) { bad_erase++; return -8; }
    for (i = 0; i < n; i++) nor[off + i] &= s[i];
    return 0;
}
static int ota_fread(uint32_t off, void *dst, uint32_t n) { memcpy(dst, nor + off, n); return 0; }
static void ota_show(uint32_t step, int32_t code) { if (step == 9) last_code = code; }
static void ota_commit(const uint8_t *parm) { committed = 1; memcpy(committed_parm, parm, 112); }

#include "../firmware/src/ota.c"

static uint32_t ota_body_off(void)                  /* ota.bin data + 0x20 in the logical image */
{
    uint8_t h[0x400];
    uint32_t i, n;
    memcpy(h, logical, sizeof h);
    ota_jl_enc(h, 0x40);
    n = ota_rd16(h + 8);
    for (i = 0; i < n; i++) {
        uint8_t *e = h + 0x40 + i * 0x50u;
        ota_jl_enc(e, 0x50);
        if (ota_rd16(e) == 100) return ota_rd32(e + 8) + 0x20u;
    }
    return 0;
}

/* rewrite flash.bin's size in the logical image's UFW entry list (the entries' and the header's CRCs too): a package
 * of the same chip whose app area is another board's size */
static void set_fl_size(uint8_t *lg, uint32_t size)
{
    uint8_t h[0x40 + 11 * 0x50];
    uint32_t i, n;
    memcpy(h, lg, sizeof h);
    ota_jl_enc(h, 0x40);
    n = ota_rd16(h + 8);
    for (i = 0; i < n; i++) {
        uint8_t *e = h + 0x40 + i * 0x50u;
        ota_jl_enc(e, 0x50);
        if (ota_rd16(e) == 0)
            ota_wr32(e + 12, size);
        ota_jl_enc(e, 0x50);
    }
    ota_wr16(h + 2, ota_crc16(h + 0x40, n * 0x50u, 0));   /* (over the entries as stored) */
    ota_wr16(h, ota_crc16(h + 2, 0x3E, 0));
    ota_jl_enc(h, 0x40);
    memcpy(lg, h, 0x40 + n * 0x50u);
}

static int check(const char *what, int ok)
{
    printf("%-52s %s\n", what, ok ? "ok" : "FAIL");
    return ok ? 0 : 1;
}

#if BOARD_SMK37
static void make_own_ldr(void)           /* a loader as build.py wraps one: outer head (CRC, 0x20, length, 0x41), body */
{
    uint32_t len = 7000u, i;
    memset(SMK_LDR, 0, 0x20);
    for (i = 0; i < len; i++)
        SMK_LDR[0x20 + i] = (uint8_t)(i * 37u + 11u);
    ota_wr16(SMK_LDR + 2, ota_crc16(SMK_LDR + 0x20, len, 0));
    ota_wr32(SMK_LDR + 4, 0x20u);
    ota_wr32(SMK_LDR + 8, len);
    SMK_LDR[12] = 0x41;
    ota_wr16(SMK_LDR, ota_crc16(SMK_LDR + 2, 30, 0));
    smk_ldr_len = len + 0x20u;
}
#define T_EMB ota_emb
#else
#define T_EMB 0
#define SMK_LDR ((uint8_t *)0)
#define smk_ldr_len 0u
#endif

static int area_erased(void)
{
    uint32_t i;
    for (i = T_AREA; i < T_AREA_HI; i++) if (nor[i] != 0xFF) return 0;
    return 1;
}

static void reset_dev(void)
{
    memset(nor, 0xFF, sizeof nor);
    memcpy(nor, logical + 0x400, 0x4000);                 /* device flash head = package flash.bin head */
    rx_full = 0; requests = 0; ident_replies = 0; committed = 0; last_code = 0;
    mute_after = 0xFFFFFFFFu; corrupt_at = NULL; bad_erase = 0; erases = 0;
}

int main(int argc, char **argv)
{
    FILE *f;
    uint8_t *raw;
    size_t n, i;
    int bad = 0, rc, official = argc > 2 && !strcmp(argv[2], "official");
    size_t blocks = 20;
    if (argc < 2) { printf("usage: ota_test FILE.fwsc [official]\n"); return 2; }
#if BOARD_SMK37
    make_own_ldr();
#endif
    f = fopen(argv[1], "rb");
    if (!f) { perror(argv[1]); return 2; }
    raw = malloc(0x200000);
    n = fread(raw, 1, 0x200000, f);
    fclose(f);
    if (n < 20 * 48 + 0x4400) { printf("%s: too short for a package\n", argv[1]); return 2; }
    logical = malloc(n);
    while (official && (blocks + 1) * 48 <= n && blocks < 64 && raw[blocks * 48 + 47] == 0x7D)
        blocks++;                                          /* (M-VAVE's: more blocks, the unused marker 0x7D) */
    for (i = 0; i < blocks; i++) memcpy(logical + i * 47, raw + i * 48, 47);   /* drop the marker bytes */
    memcpy(logical + blocks * 47, raw + blocks * 48, n - blocks * 48);
    logical_len = n - blocks;

    /* handshake outside a session */
    reset_dev();
    {
        uint8_t m[7] = {0, 0x59, 0x11, 0, 0, 0, 0xFF};
        host_reply(m, 7);
        ota_service();
        bad += check("handshake answered", ident_replies == 1);
        bad += check("identity frame is " FELUCCA_ID,
                     ota_msg[2] == 0x11 && !memcmp(ota_msg + 6, FELUCCA_ID, sizeof FELUCCA_ID - 1));
    }

    /* full session */
    reset_dev();
    rc = ota_session();
    printf("  %u requests\n", requests);
    bad += check("session commits (flash.bin a size this board takes)", rc == 0 && committed);
    if (official && T_SMK)
        bad += check("headers + the head check + confirm, no loader read", requests >= 36u && requests <= 40u);
    else if (official)                                     /* ((2.0.2) the FM-1's: M-VAVE's loader read and staged too) */
        bad += check("headers + the head check + the loader + confirm", requests >= 70u && requests <= 85u);
    else
        bad += check("headers + loader + confirm, no head reads", requests >= 10u && requests <= 30u);
    {
        uint8_t *h = nor + T_AREA, *p = committed_parm;
        uint32_t k, zero = 1;
        for (k = 8u + sizeof T_PARM_ID - 1u; k < 0x28u; k++)
            zero &= p[k] == 0;
        if (official && T_SMK)
            bad += check("M-VAVE's package: Skiff's own loader staged, whole", T_EMB &&
                         !memcmp(nor + T_AREA + 0x20u, SMK_LDR + 0x20u, smk_ldr_len - 0x20u) &&
                         ota_rd32(h + 8) == smk_ldr_len);
        else
            bad += check("staged body == the package's loader", !T_EMB &&
                         !memcmp(nor + T_AREA + 0x20u, logical + ota_body_off(), 64));
        bad += check("LOADER.BIN head CRC",
                     (h[0] | h[1] << 8) == ota_crc16(h + 2, 30, 0) && !memcmp(h + 16, "LOADER.BIN", 10));
        bad += check("record at the area end - 256 == RAM record", !memcmp(nor + T_AREA_HI - 0x100u, p, 112));
        bad += check("parm identity " T_PARM_ID ", zero to +0x27",
                     !memcmp(p + 8, T_PARM_ID, sizeof T_PARM_ID - 1u) && zero);
        bad += check("record CRC / type / magic / ota_addr",
                     (p[0] | p[1] << 8) == ota_crc16(p + 2, 78, 0) && (p[2] | p[3] << 8) == 0x5A0D &&
                     (p[6] | p[7] << 8) == 0x5441 && ota_rd32(p + 72) == T_AREA);
        bad += check("nothing written outside the staging area", bad_erase == 0);
    }
    /* boot cleanup erases it */
    bad += check("boot cleanup erases the area", ota_boot_cleanup() == 1 && area_erased());
    bad += check("second boot: nothing to do", ota_boot_cleanup() == 0);

    /* 1.6.1: another board's package (flash.bin not this board's app area size): refused in step 1, nothing erased;
     * ((2.0.2) after the header's 2 reads exactly: web/fm1ota.js stockRefusal counts on it) */
    {
        uint8_t keep[0x40 + 11 * 0x50];
        memcpy(keep, logical, sizeof keep);
        reset_dev();
        set_fl_size(logical, T_FL_OTHER);
        rc = ota_session();
        bad += check("another board's size (" T_FL_OTHER_NAME "): -15 after 2 reads, no commit, no erase",
                     rc == -15 && requests == 2u && !committed && erases == 0 && area_erased());
#if !BOARD_SMK37
        reset_dev();                                       /* ((2.0.2, #64) V16's size: the official loader's alone */
        set_fl_size(logical, T_FL_V16);
        rc = ota_session();
        if (official)
            bad += check("V16's size (0xA9000), the official loader: commits", rc == 0 && committed);
        else
            bad += check("V16's size (0xA9000), Skiff's own loader: -15, no commit, no erase",
                         rc == -15 && requests == 3u && !committed && erases == 0 && area_erased());
#endif
        memcpy(logical, keep, sizeof keep);
    }
    /* (2.0.2, #64) the official loader rewrites the head: a unit whose head is not the package's (V15's package on a unit
     * V16 started, or back) is refused, -5 at the head's first read after the 3 before it (that block differs), nothing
     * erased: web/fm1ota.js stockRefusal names the other version from where the reads stopped ((2.0.3) an SMK-37's:
     * not V016's) */
    if (official) {
        reset_dev();
        nor[0x20] ^= 0xFFu;
        rc = ota_session();
        bad += check("the unit's head not the package's: -5 after 4 reads, no commit, no erase",
                     rc == -5 && requests == 4u && !committed && erases == 0 && area_erased());
    }
    /* host disappears in the middle */
    reset_dev();
    mute_after = 4;
    rc = ota_session();
    bad += check("host gone -> no commit, area clean", rc < 0 && !committed && area_erased());

    /* host never confirms */
    reset_dev();
    mute_after = 0xFFFFFFFFu;
    {
        uint32_t total;
        rc = ota_session();
        total = requests;                                  /* requests of a full run incl. confirm */
        reset_dev();
        mute_after = total - 1;                            /* answer everything but the confirmation */
        rc = ota_session();
        bad += check("no 'success' -> -13, no commit, area clean", rc == -13 && !committed && area_erased());
    }

    printf("%s\n", bad ? "OTA TEST FAILED" : "ota test passed");
    return bad != 0;
}
