/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments */
/* The firmware side of storage.c (FELUCCA_FLASH): flash reads in short IRQ-off windows so the
 * audio keeps up, erases and writes only inside the storage areas, the audio buffer silenced
 * first. The host tests (storage_test.c) provide their own st_* on a simulated NOR. */
static uint8_t flash_ok;                 /* JEDEC id matched at boot (persist_boot) */
static int st_read(uint32_t off, void *dst, uint32_t n)   /* 256-byte IRQ-off windows: audio keeps up */
{
    uint8_t *d = dst;
    while (n) {
        uint32_t k = n > 256u ? 256u : n, f = irq_save();
        int rc = FL_FAR(fl_read_ram)(off, d, k);
        irq_restore(f);
        if (rc)
            return rc;
        off += k;
        d += k;
        n -= k;
    }
    return 0;
}
static void audio_silence(void)                 /* IRQs off: the DMA would loop stale audio (buzz). Called before */
{                                               /* every erase (here, ota_hw.c, editor.c's sample slots) */
    uint32_t i;
    for (i = 0; i < sizeof abuf / sizeof abuf[0]; i++)
        abuf[i] = 0;
#if !BOARD_SMK37                                /* (the SMK-37's button LEDs are latched in the 595s: no flash) */
    fm1__led_lines(0);                          /* (Felucca #236) the erase stops the LED scan for ~17 ms: one column */
#endif                                          /* would stay lit at full duty and the rest dark, a flash of the whole
                                                 * panel. Dark rows: the panel just drops out; the tick relights them */
}
#if BOARD_SMK37
static void st_stock_release(void);             /* storage.c: the stock mapping's end marker */
static int st_in_usrflash(uint32_t off);
#endif
static int st_erase(uint32_t off)
{
    uint32_t took, f;
    int rc;
#if BOARD_SMK37
    if (!FL_STORE_OK(off, 0x1000u) && !FL_STOCKTAG_OK(off, 0x1000u))
        return -8;
    if (st_in_usrflash(off))
        st_stock_release();                     /* before the first erase in USRFLASH: see storage.c */
#else
    if (!FL_STORE_OK(off, 0x1000u))
        return -8;
#endif
    f = irq_save();
    audio_silence();
    rc = FL_FAR(fl_erase4k_ram)(off, &took);
    irq_restore(f);
    return rc;
}
static int st_prog(uint32_t off, const void *src, uint32_t n)
{
    if (!FL_STORE_OK(off, n))                   /* only inside the storage areas */
        return -8;
    return fl_write(off, src, n);
}
